package org.jivesoftware.smack.util;

public abstract interface ReaderListener
{
  public abstract void read(String paramString);
}


/* Location:           C:\Users\Administrator\Documents\ds\反编译\AndroidKiller_v1.3.1\projects\Jungledsq_ppc\ProjectSrc\smali\
 * Qualified Name:     org.jivesoftware.smack.util.ReaderListener
 * JD-Core Version:    0.7.0.1
 */