package org.jivesoftware.smackx;

import org.jivesoftware.smackx.packet.PEPEvent;

public abstract interface PEPListener
{
  public abstract void eventReceived(String paramString, PEPEvent paramPEPEvent);
}


/* Location:           C:\Users\Administrator\Documents\ds\反编译\AndroidKiller_v1.3.1\projects\Jungledsq_ppc\ProjectSrc\smali\
 * Qualified Name:     org.jivesoftware.smackx.PEPListener
 * JD-Core Version:    0.7.0.1
 */