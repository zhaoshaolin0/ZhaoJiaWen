package org.jivesoftware.smackx.muc;

public class DefaultParticipantStatusListener
  implements ParticipantStatusListener
{
  public void adminGranted(String paramString) {}
  
  public void adminRevoked(String paramString) {}
  
  public void banned(String paramString1, String paramString2, String paramString3) {}
  
  public void joined(String paramString) {}
  
  public void kicked(String paramString1, String paramString2, String paramString3) {}
  
  public void left(String paramString) {}
  
  public void membershipGranted(String paramString) {}
  
  public void membershipRevoked(String paramString) {}
  
  public void moderatorGranted(String paramString) {}
  
  public void moderatorRevoked(String paramString) {}
  
  public void nicknameChanged(String paramString1, String paramString2) {}
  
  public void ownershipGranted(String paramString) {}
  
  public void ownershipRevoked(String paramString) {}
  
  public void voiceGranted(String paramString) {}
  
  public void voiceRevoked(String paramString) {}
}


/* Location:           C:\Users\Administrator\Documents\ds\反编译\AndroidKiller_v1.3.1\projects\Jungledsq_ppc\ProjectSrc\smali\
 * Qualified Name:     org.jivesoftware.smackx.muc.DefaultParticipantStatusListener
 * JD-Core Version:    0.7.0.1
 */