package org.jivesoftware.smackx.workgroup;

public abstract interface WorkgroupInvitationListener
{
  public abstract void invitationReceived(WorkgroupInvitation paramWorkgroupInvitation);
}


/* Location:           C:\Users\Administrator\Documents\ds\反编译\AndroidKiller_v1.3.1\projects\Jungledsq_ppc\ProjectSrc\smali\
 * Qualified Name:     org.jivesoftware.smackx.workgroup.WorkgroupInvitationListener
 * JD-Core Version:    0.7.0.1
 */