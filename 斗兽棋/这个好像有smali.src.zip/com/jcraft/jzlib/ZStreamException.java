package com.jcraft.jzlib;

import java.io.IOException;

public class ZStreamException
  extends IOException
{
  public ZStreamException() {}
  
  public ZStreamException(String paramString)
  {
    super(paramString);
  }
}


/* Location:           C:\Users\Administrator\Documents\ds\反编译\AndroidKiller_v1.3.1\projects\Jungledsq_ppc\ProjectSrc\smali\
 * Qualified Name:     com.jcraft.jzlib.ZStreamException
 * JD-Core Version:    0.7.0.1
 */