package hk.doppio.game.jungle;

public final class R
{
  public static final class anim
  {
    public static final int fade = 2130968576;
  }
  
  public static final class attr {}
  
  public static final class color
  {
    public static final int transparent_background = 2131034112;
  }
  
  public static final class drawable
  {
    public static final int button_exit = 2130837504;
    public static final int button_network = 2130837505;
    public static final int button_vs_2p = 2130837506;
    public static final int button_vs_ai = 2130837507;
    public static final int chess_blue_cat = 2130837508;
    public static final int chess_blue_dog = 2130837509;
    public static final int chess_blue_elephant = 2130837510;
    public static final int chess_blue_lair = 2130837511;
    public static final int chess_blue_leopard = 2130837512;
    public static final int chess_blue_lion = 2130837513;
    public static final int chess_blue_rat = 2130837514;
    public static final int chess_blue_tiger = 2130837515;
    public static final int chess_blue_wolf = 2130837516;
    public static final int chess_red_cat = 2130837517;
    public static final int chess_red_dog = 2130837518;
    public static final int chess_red_elephant = 2130837519;
    public static final int chess_red_lair = 2130837520;
    public static final int chess_red_leopard = 2130837521;
    public static final int chess_red_lion = 2130837522;
    public static final int chess_red_rat = 2130837523;
    public static final int chess_red_tiger = 2130837524;
    public static final int chess_red_wolf = 2130837525;
    public static final int icon = 2130837526;
    public static final int jungle = 2130837527;
    public static final int title = 2130837528;
    public static final int title_bg = 2130837529;
    public static final int transparent = 2130837530;
  }
  
  public static final class id
  {
    public static final int jungle = 2131230720;
    public static final int linearLayout1 = 2131230721;
    public static final int linearLayout2 = 2131230722;
    public static final int menubutton1 = 2131230725;
    public static final int menubutton2 = 2131230726;
    public static final int menubutton3 = 2131230727;
    public static final int menubutton4 = 2131230728;
    public static final int progressBar = 2131230723;
    public static final int progressTextView = 2131230724;
    public static final int title = 2131230729;
  }
  
  public static final class layout
  {
    public static final int jungle_layout = 2130903040;
    public static final int loading_layout = 2130903041;
    public static final int menu_layout = 2130903042;
    public static final int title_layout = 2130903043;
  }
  
  public static final class string
  {
    public static final int app_name = 2131099648;
    public static final int find_op = 2131099652;
    public static final int init_conn = 2131099651;
    public static final int is_blue = 2131099655;
    public static final int is_red = 2131099656;
    public static final int jungle_layout_text = 2131099649;
    public static final int lose = 2131099658;
    public static final int op_exit = 2131099654;
    public static final int progress_text = 2131099650;
    public static final int wait_op = 2131099653;
    public static final int win = 2131099657;
  }
  
  public static final class style
  {
    public static final int Transparent = 2131165184;
  }
}


/* Location:           C:\Users\Administrator\Documents\ds\反编译\AndroidKiller_v1.3.1\projects\Jungledsq_ppc\ProjectSrc\smali\
 * Qualified Name:     hk.doppio.game.jungle.R
 * JD-Core Version:    0.7.0.1
 */